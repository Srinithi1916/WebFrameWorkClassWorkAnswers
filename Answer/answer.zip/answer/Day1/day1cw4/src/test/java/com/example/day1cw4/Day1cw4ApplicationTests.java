package com.example.day1cw4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day1cw4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
