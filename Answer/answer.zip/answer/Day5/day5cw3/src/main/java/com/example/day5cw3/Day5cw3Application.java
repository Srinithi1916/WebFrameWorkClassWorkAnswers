package com.example.day5cw3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day5cw3Application {

	public static void main(String[] args) {
		SpringApplication.run(Day5cw3Application.class, args);
	}

}
